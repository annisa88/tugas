# Articles Web App

## Laravel 8 with Bootstrap Auth

Rahman Nurhidayat [1942492]

## How to run

Must git, composer, web server, nodejs, local database installed in your device.
after that git clone.

> composer install

for install package laravel

> npm install

for install package nodejs

> npm run dev

for sycn code laravel with nodejs

> php artisan key:generate

generate env key

and than configuration your database local

if already all required. you can running server

> php artisan serve

## My Contact :

[Instagram ](https://www.instagram.com/rahman_nhidayat)
[Github Pages](https://www.github.com/rahmannurhidayat022)
