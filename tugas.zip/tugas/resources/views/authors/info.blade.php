@extends('layouts.authors')

@section('content')
<div class="card p-2">
 <div class="card-title p-2">Developer</div>
 <div class="card-body">
  Hi! I'm <strong>Annisa [1942453]</strong>, this for myexam.
 <ul>
  <li>
   <p>Github : <a href="https://github.com/annisa88">https://github.com/annisa88</a></p>
  </li>
 </ul> 
 </div>
</div>
@endsection