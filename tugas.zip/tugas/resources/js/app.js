import 'bootstrap';
import '@popperjs/core';
import 'tinymce';
require('tinymce/themes/silver');
require('tinymce/icons/default');